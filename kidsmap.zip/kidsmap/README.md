# KidsMap — Telegram Mini App
## Инструкция по запуску

---

## 📁 Структура файлов

```
kidsmap/
├── index.html       ← Лента мероприятий (Главная)
├── event.html       ← Карточка мероприятия
├── tickets.html     ← Мои билеты
├── favorites.html   ← Избранное
├── profile.html     ← Профиль
├── login.html       ← Регистрация / Вход
├── checkout.html    ← Оформление и оплата
├── css/
│   └── style.css    ← Все стили
└── js/
    └── app.js       ← Общие функции
```

---

## 🚀 Шаг 1 — Создаём бота в Telegram

1. Открыть @BotFather в Telegram
2. Написать `/newbot`
3. Придумать имя: `KidsMap Bot`
4. Придумать username: `kidsmap_bot` (должен заканчиваться на `bot`)
5. Сохранить токен: `7654321:AABbCcDd...` — он понадобится для бэкенда

---

## 🌐 Шаг 2 — Публикуем сайт (HTTPS обязателен!)

### Вариант А: Vercel (бесплатно, 5 минут)
1. Зарегистрироваться на vercel.com
2. Создать папку `kidsmap/` с этими файлами
3. `npm i -g vercel` → `vercel` → следовать инструкциям
4. Получите ссылку вида: `https://kidsmap-xyz.vercel.app`

### Вариант Б: GitHub Pages (бесплатно)
1. Создать репозиторий на github.com
2. Загрузить все файлы
3. Settings → Pages → Source: main branch
4. Ссылка: `https://username.github.io/kidsmap`

### Вариант В: Netlify (бесплатно)
1. Зайти на netlify.com
2. Перетащить папку `kidsmap/` в браузер
3. Мгновенная публикация!

---

## ⚙️ Шаг 3 — Подключаем к Telegram боту

В @BotFather:
```
/mybots
→ Выбрать kidsmap_bot
→ Bot Settings
→ Menu Button
→ Configure menu button
→ Вставить URL: https://kidsmap-xyz.vercel.app
→ Написать текст кнопки: "Открыть KidsMap"
```

Для Main Mini App (кнопка на профиле бота):
```
/mybots → kidsmap_bot
→ Bot Settings
→ Configure Mini App
→ Enable Mini App
→ Вставить URL: https://kidsmap-xyz.vercel.app
```

---

## 🔗 Прямые ссылки на страницы

| Страница      | Ссылка в мини-апп                             |
|---------------|-----------------------------------------------|
| Главная       | `https://ВАШ-URL/index.html`                 |
| Мероприятие   | `https://ВАШ-URL/event.html?id=watercolor`   |
| Профиль       | `https://ВАШ-URL/profile.html`               |
| Билеты        | `https://ВАШ-URL/tickets.html`               |
| Избранное     | `https://ВАШ-URL/favorites.html`             |
| Оплата        | `https://ВАШ-URL/checkout.html?id=watercolor`|
| Логин         | `https://ВАШ-URL/login.html`                 |

### ID мероприятий для передачи в параметр `?id=`:
- `watercolor` — Рисование акварелью
- `football` — Футбол для малышей
- `theatre` — Театральный кружок
- `chess` — Шахматная школа
- `swim` — Плавание для детей
- `english` — Английский для малышей

---

## 🧪 Шаг 4 — Тестирование

### Тест без Telegram (в браузере):
Просто открыть `index.html` — всё работает как обычный сайт.

### Тест в Telegram Desktop:
1. Написать боту любое сообщение
2. Нажать кнопку меню (слева внизу в чате)
3. Откроется Mini App

### Debug режим (Android):
1. Telegram Settings → прокрутить вниз → удерживать версию 2 секунды
2. Enable WebView Debug
3. Подключить телефон к ПК, открыть `chrome://inspect/#devices`

---

## 💳 Шаг 5 — Подключение реальной оплаты

Для оплаты через Telegram Payments:
1. В @BotFather: `/mybots → Payments → Connect provider`
2. Подключить платёжного провайдера (Payme, Stripe и т.д.)
3. В `checkout.html` заменить функцию `pay()`:

```javascript
// Вместо showPopup — настоящий инвойс:
async function pay() {
  // 1. Запрашиваем invoice_url у вашего бэкенда
  const res = await fetch('https://ваш-бэкенд.com/create-invoice', {
    method: 'POST',
    body: JSON.stringify({ event_id: id, child: 'amina' })
  });
  const { invoice_url } = await res.json();

  // 2. Открываем нативный экран оплаты Telegram
  Telegram.WebApp.openInvoice(invoice_url, (status) => {
    if (status === 'paid') {
      window.location.href = 'tickets.html';
    }
  });
}
```

---

## 🔐 Шаг 6 — Верификация пользователя на бэкенде

Данные из `Telegram.WebApp.initData` нужно проверять на сервере:

```python
# Python пример
import hmac, hashlib

def verify_telegram_data(init_data: str, bot_token: str) -> bool:
    data = dict(x.split('=') for x in init_data.split('&'))
    received_hash = data.pop('hash')
    
    check_string = '\n'.join(f'{k}={v}' for k, v in sorted(data.items()))
    secret_key = hmac.new(b'WebAppData', bot_token.encode(), hashlib.sha256).digest()
    expected = hmac.new(secret_key, check_string.encode(), hashlib.sha256).hexdigest()
    
    return expected == received_hash
```

---

## 📱 Что работает уже сейчас (без бэкенда)

✅ Лента мероприятий с карточками  
✅ Поиск по названию  
✅ Фильтры по категориям  
✅ Карточка мероприятия с деталями  
✅ Добавление в избранное  
✅ Удаление из избранного с анимацией  
✅ Страница билетов  
✅ Страница профиля  
✅ Оформление билета (checkout)  
✅ Кнопка "На карте" → Google Maps  
✅ Haptic feedback  
✅ Автоматическая тёмная/светлая тема из Telegram  
✅ Данные пользователя из Telegram (имя, фото)  
✅ Уведомления через requestWriteAccess  

## 🔮 Нужен бэкенд для:

⬜ Реальная оплата  
⬜ Сохранение данных пользователей  
⬜ Управление реальными мероприятиями  
⬜ Push-уведомления через бота  
⬜ История платежей  
